This theme or plugin item is entirely licensed under the General Public License
(GPL). You will find a copy of the license text in the same directory as this
text file. Read more about licensing here:

http://themeforest.net/licenses
