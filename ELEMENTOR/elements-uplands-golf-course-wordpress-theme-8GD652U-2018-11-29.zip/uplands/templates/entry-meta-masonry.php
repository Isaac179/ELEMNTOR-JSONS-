<div class="post-meta">
    <?php echo get_the_category_list('&nbsp;', false, get_the_ID()); ?>
</div>