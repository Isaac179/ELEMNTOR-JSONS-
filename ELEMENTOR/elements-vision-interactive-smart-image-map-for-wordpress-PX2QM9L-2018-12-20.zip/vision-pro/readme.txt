=== Vision Interactive For WordPress ===
Contributors: Avirtum
Donate link: https://www.paypal.me/avirtum/5
Tags: image map, floor plan, real estate, visual presentation
Requires at least: 4.0
Tested up to: 5.0.0
Stable tag: 1.0.2
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html


Create great interactive images for your site that empowers publishers and bloggers, the plugin provides an easy way for you to convert a static image into the interactive media brochures, booklets, infographic, visual maps, building plans and etc.


== Description ==

Vision Interactive is a lightweight and rich-feature plugin helps you enhance images with additional information and links. With this plugin you are able to easily annotate images with text, shapes and icons, draw attention to areas and features on images. You can then use them in posts that empower publishers and bloggers to create more engaging content. It provides an easy way for you to convert a static image into the online interactive media brochures or booklets, image maps, immersive storytelling in seconds. The plugin can be deployed easily and runs on all modern browsers and mobile devices.

Using **[vision id="123"]** shortcode, you can publish an interactive image on any Page or Post in your WordPress sites.

This is the **LITE version** of the official [Vision Interactive - Image Map Builder for WordPress](https://1.envato.market/nXjz9) plugin which comes with support and doesn't have some limitations.

= The sample of how to create an interactive infographics =
https://youtu.be/OPGzAZJuK54


= Features =
* **Markers** - add images, links, text or svg objects
* **Tooltips** - small boxes for tiny information
* **Popovers** - pop-up boxes for large amounts of info
* **Smart** - tooltips & popovers can occupy the best position 
* **Responsive** - automatically adjust elements to image size
* **Animations** - tooltips have over 100 show/hide effects
* **Powerful Interface** - many options & capabilities
* **AJAX saving** - save your config without page reloading
* **JSON config** - the config is served from the filesystem instead of the database for better performance
* **Code editors** - add extra css styles or js code with syntax highlighting
* **Customization** - create you own theme

You can place any markers by simply clicking on an image. Each marker can have its own tooltip and popover which gives an excellent opportunity for creating engaging visual stories & presentations.

== Installation ==
* From the WP admin panel, click "Plugins" -> "Add new"
* In the browser input box, type "Vision"
* Select the "Vision" plugin and click "Install"
* Activate the plugin

Alternatively, you can manually upload the plugin to your wp-content/plugins directory


== Screenshots ==
1. Manage interactive images
2. Create layers
3. Edit tooltips
4. Final result with tooltips
5. Edit popover (inbox type)
6. Final result with popover


== Frequently Asked Questions ==

= I'd like access to more features and support. How can I get them? =
You can get access to more features and support by visiting the CodeCanyon website and
[purchasing the plugin](https://codecanyon.net/item/vision-interactive-image-map-builder-for-wordpress/22919726?ref=avirtum).
Purchasing the plugin gets you access to the full version of the ImageLinks plugin, automatic updates and support.

= What is the difference between Lite and PRO =
The lite version has only two limits:
1) You can create and use only one item
2) Your published item will have a little icon
All other features are the same as PRO has.


== Changelog ==

= 1.0.2 =
 * Fix: can't save a big config

= 1.0.1 =
 * New: next & prev layer navigation
 * Fix: light theme

= 1.0.0 =
 * Initial release